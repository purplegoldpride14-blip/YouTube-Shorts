---
name: nostalgia-shorts-pipeline
description: >
  Produce a standalone vertical YouTube Short end to end - niche and topic
  selection, mode selection (still images or motion clips, voiced or
  unvoiced), script (if voiced), narration audio, aligned SRT (if voiced),
  scene plan, visual style, beat batch (5 images via Nano Banana 2, or 4
  clips via Kling 2.5), assembly, and description. No thumbnail, no
  highlight-clip stage - the Short itself is the only deliverable. Use when
  the user wants to make a new nostalgia (or other niche) Short, resume an
  interrupted one, or run any single stage. Trigger on "new short", "make a
  short", "resume <slug>", or a request to write a Short script, build an
  SRT, plan beats, assemble a Short, or write a Short's description.
---

# Nostalgia Shorts pipeline

Every path below is relative to the repository root, not to this file.

Read `PROCESS.md` before starting. Every number lives in `pipeline/config.py`;
the docs describe it and never override it.

## Always run first

```bash
cd pipeline && python3 preflight.py
```

Installs ffmpeg if missing, checks the domain allowlist. If a domain is
blocked, STOP and tell the user - the allowlist is fixed at session start and
can't be changed mid-run.

## Two approval gates, nothing else

**Gate 1 — topic.** Ask for the niche (likely nostalgia), research what's
over-performing in it, propose exactly ten ideas, wait for the pick.

**Gate 2 — style.** Offer visual styles that are working right now, write the
style block, generate beat 1 only at locked settings, show it, wait for
approval.

Between and after these, run without check-ins. Once beat 1 is approved,
generate the rest of the fixed-count batch automatically, no continuation
prompts. There is no thumbnail check and no highlight-clip stage - this
pipeline doesn't produce either.

## Stage sequence

1. **Niche.** `playbooks/01_niche_and_topic.md`. Menu (nostalgia, or
   something else) plus a write-in option; accept reference images or links.
2. **Topic and mode.** Research the niche for what's currently
   over-performing, propose ten topic ideas (a decade/city/subculture/trend,
   not a single event), wait for the pick. Then ask for asset_mode
   (images/clips) and narration (full/none) and write both immediately:
   `new_project.py <slug> --asset-mode images|clips --narration full|none --niche "..." --topic "..."`
   Propose three to five titles off the chosen topic and save one before
   moving on - don't defer this to the description stage.
3. **Script — narration == "full" only.** `playbooks/02_script.md`. 80-115
   words, averaging 30-45s. Then:
   `python3 script_check.py <script.txt> ../projects/<slug> --fix`
   As soon as this passes, commit and push `script.txt` and
   `narration_part1.txt` before asking the user to generate audio - they need
   it pulled from the repo to hand to OpenArt.
   If narration == "none", skip straight to stage 5.
4. **Narration — narration == "full" only.** The user generates the audio with
   OpenArt's own "Create Voice Over" feature (ElevenLabs voices, in the
   OpenArt app - not reachable through the OpenArt MCP tools available here,
   only `openart_generate_image`/`openart_generate_video` are) and drops the
   file(s) in `projects/<slug>/audio/`. Then:
   `python3 audio_merge.py ../projects/<slug>/audio ../projects/<slug>`
   Import that same file to Descript as a composition via the Descript MCP,
   export one SRT into `projects/<slug>/srt/`. Then:
   `python3 srt_build.py ../projects/<slug>/srt ../projects/<slug>`
5. **Scene plan.**
   - narration == "full": `python3 scene_plan.py propose ../projects/<slug>`,
     read `beats_draft.txt`, adjust `boundaries.json` if a cut lands badly,
     then `python3 scene_plan.py build ../projects/<slug>`. This always
     produces exactly 5 (images) or 4 (clips) beats - never more, never fewer.
   - narration == "none": write `out/beats.json` by hand, exactly 5 or 4
     entries, `[{"label": "...", "dur": ...}, ...]` - this is where the topic
     actually becomes four or five specific moments, not one vague beat
     repeated. Then `python3 scene_plan.py beats ../projects/<slug>`.
     Also drop a music bed into `projects/<slug>/audio/music.<ext>` before
     assembly - this pipeline doesn't generate or license music itself.
6. **Style.** `playbooks/03_visual_style.md`. Offer options, accept a
   write-in or reference images, write `style.json`. Original art only -
   never instruct the model to reproduce a specific real photo, film frame,
   album cover, or trademarked logo; describe the era and scene instead.
7. **Beat 1, then the batch.** Generate beat 1 alone at locked settings -
   `nano-banana-2 | text2image | 2K | 9:16` for images,
   `Kling 2.5 | quality mode | 5s | audio off | 9:16` for clips. Show it,
   wait for approval (gate 2), then write `prompts.json` mapping beat number
   to prompt and run the batch to completion, autonomously:
   `manifest.py init / next / submit / record / fetch / verify / status`,
   in a loop, until `status` says all done. Never hold batch state in
   context - `status` is the source of truth.
8. **Assemble.** `python3 assemble.py ../projects/<slug>`. Branches
   automatically on `project.json`'s asset_mode/narration - Ken Burns stills
   or trimmed/looped clips, word-synced captions from `out/captions.srt` or
   beat-labeled captions from the beat text, narration audio or the music bed.
   Nothing to choose here beyond running it.
9. **Description, then deliver.** `playbooks/04_description.md`. Use
   `prompts/description_prompt.txt`, base it on the script (if any) or the
   beat labels, then `description_check.py`. Once it passes:
   `python3 deliver.py ../projects/<slug>`
   Verifies `description.md` and `out/final.mp4` exist (plus
   `out/captions.srt` and the narration file, for narration == "full"
   projects only), mirrors the description and narration into `out/`, checks
   `out/final.mp4` against `GIT_PUSH_MAX_BYTES`. `out/` is gitignored by
   default, so this always needs `-f`:
   - **Under the limit:** git-add the file as-is.
   - **Over the limit:** `deliver.py` splits it into `<name>.part_NNN` files
     under `out/chunks/` and writes a `.sha256` next to them. Never git-add
     the oversized original. Send the chunks via chat with the sha256 and
     reassembly command (`cat <name>.part_* > <name>`).
   `deliver.py`'s own output lists exactly which paths are git-addable and
   which need chat delivery - follow it rather than reconstructing the list.
   This is bookkeeping, not judgement - do it without asking.

## Resuming

`python3 manifest.py status ../projects/<slug>` reports exactly what remains.
Downloaded frames/clips persist. Never regenerate a beat already marked done.
